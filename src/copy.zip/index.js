var vmodel = require('./vmodel');
var utils = require('./utils');
var Promise = require('promise-order');
var domReady = require('./domready');
var fastClick = require('fastclick');
var EventEmitter = require('events').EventEmitter;

exports.ready = function(foo){
    domReady(function(){
        fastClick.attach(document.body);
        typeof foo === 'function' && foo();
    });
};

exports.domReady = domReady;
exports.fastClick = fastClick;
exports.Promise = Promise;
exports.EventEmitter = EventEmitter;

exports.invoke = function(controller, initData, callback){
    if ( !callback ){
        callback = initData;
        initData = {};
    }

    var
        vm = this.init(controller, initData),
        wait = false;

    var invoke = new Promise(function(resolve, reject){
        var expose = {};
        var futureResolve = function(){ resolve(expose); };
        Object.defineProperty(expose, 'async', { set: function(value){ wait = !!value; } });

        var ret = callback.call(
            expose,         // this指针
            expose  ,       // 数据源
            controller,     // controller节点
            futureResolve,  // 异步完成
            reject          // 异步出错
        );

        if ( wait === false ){
            if ( ret ){ resolve(ret); }
            else{ resolve(expose) }
        }
    });

    return invoke.then(function(scope){
        return Promise.resolve(vm.listen(scope));
    });
};

exports.config = function(key, value){
    if ( utils.type(key, 'Object') ){
        for ( var obj in key ){
            exports.config(obj, key[obj]);
        }
    }else{
        utils[key] = value;
    }
};

exports.init = function(controller, scope){
    if ( utils.type(controller, 'String') ){
        controller = document.querySelector("[es-controller='" + controller + "']");
    }
    var vm = new vmodel();
    vm.define(controller).init(scope);
    return vm;
};