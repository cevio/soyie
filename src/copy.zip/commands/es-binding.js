/**
 * Created by evio on 15/8/31.
 */
var node = require('./node');
var utils = require('../utils');
var likeTexts = 'text,password,tel,color,date,datetime,datetime-local,month,week,time,email,number,range,search,url'.split(',');
var bindings = module.exports = function(expression){
    var DOMObject = new node(this, expression.trim());
    var bindingtype = (this.type || 'NULL').toLowerCase();
    var bindingtagname = this.tagName.toUpperCase();
    var type = null;
    this.removeAttribute('es-binding');

    switch (bindingtagname){
        case 'INPUT':
            if ( likeTexts.indexOf(bindingtype) > -1 ){ type = 'Text'; }
            else if ( bindingtype === 'radio' ){ type = 'Radio'; }
            else if ( bindingtype === 'checkbox' ){ type = 'Checkbox'; }
            else if ( bindingtype === 'file' ){ type = 'File'; }
            else{ type = 'Common'; }
            break;
        case 'SELECT': type = 'Select'; break;
        case 'TEXTAREA': type = 'Textarea'; break;
        default : type = 'Common';
    }

    bindings[type] && bindings[type](DOMObject);
    return DOMObject;
};

bindings.Textarea = bindings.Text = function(object){
    object.stop = false;
    // view 层显示具体数据方法
    Object.defineProperty(object, 'value', {
        set: function(value){
            if ( this.stop ){ this.stop = false; }
            else{ this.element.value = value; }
        }
    });
    // data 层改变数据方法
    object.element.addEventListener('input', function(){
        object.stop = true;
        utils.transdata( utils.getRealyNames(object), object.scope.$this, this.value );
    }, false);
};

bindings.Select = function(object){
    object.stop = false;
    // view 层显示具体数据方法
    Object.defineProperty(object, 'value', {
        set: function(value){
            if ( this.stop ){ this.stop = false; }
            else{
                var suc = false, i;
                for ( i = 0 ; i < this.element.options.length ; i++ ){
                    if ( this.element.options[i].value == value + '' ){
                        this.element.options[i].selected = true;
                        suc = true;
                        break;
                    }
                }
                if ( !suc ){
                    for ( i = 0 ; i < this.element.options.length ; i++ ){
                        this.element.options[i].selected = false;
                    }
                }
            }
        }
    });
    object.element.addEventListener('change', function(){
        object.stop = true;
        var value = this.value;
        if ( !value ){ value = this.options[this.selectedIndex].value; }
        utils.transdata( utils.getRealyNames(object), object.scope.$this, value );
    }, false);
};

bindings.Checkbox = function(object){
    object.stop = false;
    // view 层显示具体数据方法
    Object.defineProperty(object, 'value', {
        set: function(value){
            if ( this.stop ){ this.stop = false; }
            else{
                if ( this.element.value == value + '' ){ this.element.checked = true; }
                else{ this.element.checked = false; }
            }
        }
    });
    object.element.addEventListener('change', function(){
        object.stop = true;
        var value = this.value;
        if ( !this.checked ){ value = undefined; }
        utils.transdata( utils.getRealyNames(object), object.scope.$this, value );
    }, false);
};

bindings.Radio = function(object){
    object.stop = false;
    // view 层显示具体数据方法
    Object.defineProperty(object, 'value', {
        set: function(value){
            if ( this.stop ){ this.stop = false; }
            else{
                if ( this.element.value == value + '' ){ this.element.checked = true; }
                else{ this.element.checked = false; }
            }
        }
    });
    object.element.addEventListener('change', function(){
        object.stop = true;
        var value = this.value;
        if ( !this.checked ){ value = undefined; }
        utils.transdata( utils.getRealyNames(object), object.scope.$this, value );
    }, false);
};