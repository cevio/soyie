var datas = require('../data-model/data');
var utils = require('../utils');
var node = module.exports = function(DOM, expression){
    this.element = DOM;
    this.expression = expression;
    this.dependencies = [];
    this.scope = new datas();
};

node.prototype.render = function(){
    this.value = utils.transform(this.expression, this.scope.$alias ? this.scope : this.scope.$this);
    return this;
};

node.prototype.relation = function(){
    this.dependencies = this.scope.relation(this.expression) || [];
    return this;
};