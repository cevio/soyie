/**
 * Created by evio on 15/8/31.
 */
var node = require('./node');
var utils = require('../utils');
module.exports = function(expression){
    var DOMObject = new node(this, utils.formatExpression(expression));
    var that = this;
    this.removeAttribute('es-src');
    Object.defineProperty(DOMObject, 'value', {
        set: function(href){ that.src = href; }
    });
    return DOMObject;
};