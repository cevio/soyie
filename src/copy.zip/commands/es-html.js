/**
 * Created by evio on 15/8/31.
 */
var node = require('./node');
var utils = require('../utils');
module.exports = function(expression){
    var DOMObject = new node(this, utils.formatExpression(expression));
    var that = this;
    this.removeAttribute('es-html');
    Object.defineProperty(DOMObject, 'value', {
        set: function(html){ that.innerHTML = html; }
    });
    return DOMObject;
};