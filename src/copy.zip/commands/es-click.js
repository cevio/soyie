/**
 * Created by evio on 15/8/31.
 */
var node = require('./node');
var utils = require('../utils');
module.exports = function(expression){
    var DOMObject = new node(this, expression.trim());
    var that = this;
    this.removeAttribute('es-click');
    DOMObject.render = function(){
        DOMObject.clickcallback = new Function('scope', ';with(scope){\n' + DOMObject.expression + '\n};');
    };

    DOMObject.element.addEventListener('click', function(){
        typeof DOMObject.clickcallback === 'function'
        && DOMObject.clickcallback.call(this,
            DOMObject.scope.$alias
                ? DOMObject.scope
                : DOMObject.scope.$this
        );
    }, false);

    return DOMObject;
};