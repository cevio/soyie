exports.slice = Array.prototype.slice;
exports.REGEXP_TAGSPILTOR = /\{\{([^\}\}]+)\}\}/g;
exports.REGEXP_STRING = /(["|'])(.+?)*?\1/g;
exports.REGEXP_COMMAND_IN = /([^\s]+?)\sin\s(.+)/i;
exports.REGEXP_PARENT = /(\B\$parent\.)+?[a-zA-z_\.\$0-9]+/g;
exports.exceptTagNames = ['head', 'script', 'meta', 'link', 'title', 'script', 'hr', 'br'];

/**
 * check the type of object or return this type.
 * @param obj
 * @param type
 * @returns {*}
 */
exports.type = function(obj, type){
    var _type = Object.prototype.toString.call(obj).split(' ')[1].replace(/\]$/, '');
    if ( type ){
        return _type == type;
    }else{
        return _type;
    }
};

/**
 * mix target into source object.
 * @param source
 * @param target
 * @param overwrite
 * @returns {*}
 */
exports.mixin = function(source, target, overwrite){
    for ( var i in target ){
        if ( source[i] ){
            if ( overwrite ){
                source[i] = target[i];
            }
        }else{
            source[i] = target[i];
        }
    }
    return source;
};

/**
 * return value from scope by key.
 * @param key
 * @param value
 * @returns {*}
 */
exports.transform = function(key, value){
    try{ return (new Function('scope', ';with (scope) { return (' + key + ') || ""; };'))(value); }
    catch(e){ return ''; }
};

exports.transdata = function(expression, scope, value){
    try{
        var foo = 'scope.' + expression + '=value;';
        //console.log(foo, scope)
        (new Function('scope', 'value', foo))(scope, value);
    }catch(e){}
};

/**
 * 将表达式转义为JS表达式
 * @param expression
 * @returns {string}
 */
exports.formatExpression = function(expression){
    var pools = [];
    expression.split(exports.REGEXP_TAGSPILTOR).forEach(function(text, index){
        var isTextNodeElement = index % 2 === 1;
        if ( isTextNodeElement ){
            pools.push('(' + text + ')');
        }else{
            var ex = text.replace(/\'/g, '\\\'');
            if ( ex.length ){
                pools.push("'" + ex + "'");
            }
        }
    });
    return pools.join(' + ');
};

exports.fromatRealy = function(expname){
    var i = expname.indexOf('.');
    if ( i > -1 ){
        expname = expname.substring(i + 1);
    }
    return expname;
};

exports.getRealyNames = function(object){
    var count = object.expression.split('.');
    var expression = object.expression;
    if ( !!object.scope.$alias ){
        if ( count.length > 1 ){
            expression = count.slice(1).join('.');
        }
    }
    return expression;
};